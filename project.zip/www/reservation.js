// reservation.js
const db = firebase.firestore();
// ----------------------------------------------------
// 1. Firestore の参照を取得とグローバル変数の定義
// ----------------------------------------------------
window.selectedSeatId = ''; // 選択された席のID (例: 'Firstfloor1')

// ----------------------------------------------------
// 2. ページ初期化処理とリアルタイム状態監視
// ----------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    // localStorageから席IDを取得
    window.selectedSeatId = localStorage.getItem('selectedSeatId');
    
    // HTML要素の参照を取得 (HTMLにこれらのIDが必要です)
    const displayElement = document.getElementById('currentSeatDisplay');
    const reserveButton = document.getElementById('reserveButton'); 
    const releaseButton = document.getElementById('releaseButton'); 

    if (!window.selectedSeatId) {
        displayElement.textContent = 'エラー: 席が選択されていません。';
        return; 
    }

    // 席IDを表示
    displayElement.textContent = `選択中の席: ${window.selectedSeatId}`;
    
    // 席の状態をリアルタイムで監視
    startSeatListener(window.selectedSeatId, reserveButton, releaseButton, displayElement);
});


/**
 * 選択された席の状態をFirestoreからリアルタイムで監視し、ボタンの状態を更新する
 */
function startSeatListener(seatId, reserveButton, releaseButton, displayElement) {
    const seatDocRef = db.collection('seats').doc(seatId);

    seatDocRef.onSnapshot((doc) => {
        if (doc.exists) {
            const seatData = doc.data();
            const isOccupied = seatData.is_occupied === true; // trueでなければ空きと判断
            const userId = seatData.user_id || '不明'; // 学籍番号を取得

            if (isOccupied) {
                // 使用中の場合
                displayElement.textContent = `選択中の席: ${seatId} (現在、使用中です)`;
                if (reserveButton) reserveButton.disabled = true;  // 予約ボタンを無効化
                if (releaseButton) releaseButton.disabled = false; // 解除ボタンを有効化
            } else {
                // 空きの場合
                displayElement.textContent = `選択中の席: ${seatId} (現在、空席です)`;
                if (reserveButton) reserveButton.disabled = false; // 予約ボタンを有効化
                if (releaseButton) releaseButton.disabled = true; // 解除ボタンを無効化
            }
        } else {
            // ドキュメントが存在しない場合
            displayElement.textContent = `エラー: ${seatId} の情報が見つかりません。`;
            if (reserveButton) reserveButton.disabled = false; 
            if (releaseButton) releaseButton.disabled = true;
        }
    }, (error) => {
        console.error("Firestore監視エラー: ", error);
        displayElement.textContent = "状態取得エラーが発生しました。";
    });
}


// ------------------------------------------------------------------
// 3. 席の予約・使用開始処理 (使用中にする) - 💡 学籍番号を保存
// ------------------------------------------------------------------
function reserveSeatHandler() {
    if (!window.selectedSeatId) return;

    // 💡 ユーザーが入力した学籍番号を取得 💡
    const inputStudentId = document.getElementById('studentId').value.trim();

    if (!inputStudentId) {
        alert("学籍番号を入力してください。");
        return;
    }
    
    const seatDocRef = db.collection('seats').doc(window.selectedSeatId); 

    const seatUpdate = {
        is_occupied: true, 
        user_id: inputStudentId, // 🔴 入力された学籍番号を保存 🔴
        start_time: firebase.firestore.FieldValue.serverTimestamp() 
    };

    seatDocRef.set(seatUpdate, { merge: true }) 
        .then(() => {
            alert(`${window.selectedSeatId} を使用中にしました。`);
            window.location.href = './index.html';
        })
        .catch((error) => {
            console.error("予約エラー: ", error);
            alert("予約中にエラーが発生しました。");
        });
}


// ------------------------------------------------------------------
// 4. 席の使用中を解除する前に認証を行う関数 - 💡 解除ボタンのonclickはこちら
// ------------------------------------------------------------------
function checkAndReleaseSeat() {
    if (!window.selectedSeatId) return;

    // 1. ユーザーが入力した学籍番号を取得
    const inputStudentId = document.getElementById('studentId').value.trim();

    if (!inputStudentId) {
        alert("席を解除するには、学籍番号を入力してください。");
        return;
    }

    const seatDocRef = db.collection('seats').doc(window.selectedSeatId);

    // 2. Firestoreから現在の席のデータを取得して照合
    seatDocRef.get()
        .then(doc => {
            if (!doc.exists || !doc.data().is_occupied) {
                alert("この席は現在使用中ではありません。");
                return;
            }

            const storedStudentId = doc.data().user_id;

            // 3. 照合チェック
            if (storedStudentId === inputStudentId) {
                // 認証成功！解放処理へ進む
                // 💡 解放処理は releaseSeatHandler() に任せる
                finalReleaseSeat(); 
            } else {
                // 認証失敗
                alert("入力された学籍番号が、この席を使用したユーザーの学籍番号と一致しません。");
            }
        })
        .catch(error => {
            console.error("認証時のデータ取得エラー: ", error);
            alert("認証中にエラーが発生しました。");
        });
}


// ------------------------------------------------------------------
// 5. 席の使用中を解除する処理 (解放) - 💡 認証成功時のみ呼ばれる
// ------------------------------------------------------------------
function finalReleaseSeat() {
    if (!window.selectedSeatId) return;

    const seatDocRef = db.collection('seats').doc(window.selectedSeatId);
    
    // is_occupiedを false に設定し、user_idとstart_timeをFirestoreから削除
    const seatRelease = {
        is_occupied: false,
        user_id: firebase.firestore.FieldValue.delete(),
        start_time: firebase.firestore.FieldValue.delete()
    };

    seatDocRef.update(seatRelease) 
        .then(() => {
            alert(`${window.selectedSeatId} の使用中を解除しました。`);
        window.location.href = './index.html'; 
        })
        .catch((error) => {
            console.error("解放エラー: ", error);
            alert("解除中にエラーが発生しました。");
        });
}