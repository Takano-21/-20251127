// This is a JavaScript file
// floor1.js の内容

// floor1.js (Cloud Firestore対応版)

// ----------------------------------------------------
// 1. Firestore の参照を取得
// ----------------------------------------------------
// 🔴 複数のJSファイルで const db = ... を宣言していると重複エラーになる可能性があるため、
//    dbの取得は一度きり（例: firebase-config.js）として、ここでは単に参照を取得します。
//    ここでは、dbが未定義になるのを防ぐため、const db = ... を残します。
//    もしエラーが続く場合は、この const db = ... の行を削除してください。
document.addEventListener('DOMContentLoaded', () => {
    // 🔴 リアルタイム監視処理全体をDOMContentLoaded内に移動 🔴
    startFloorListener();
});

// ----------------------------------------------------
// 2. 席選択処理
// ----------------------------------------------------
function selectSeat(seatId) {
    localStorage.setItem('selectedSeatId', seatId);
    window.location.href = './reservation.html';
}

// ----------------------------------------------------
// 3. 全ての席の状態をリアルタイムで監視 (Firestore)
// ----------------------------------------------------
function startFloorListener() {
    // 🔴 Firestoreのコレクション参照に変更 🔴
    const seatsRef = db.collection('seats'); 

    // onSnapshotでリアルタイム監視を設定
    seatsRef.onSnapshot((snapshot) => {
        
        // 変更があったドキュメントをループ処理
        snapshot.docs.forEach(doc => {
            const seatId = doc.id;             // ドキュメントIDが 'Firstfloor1' になる
            const seat = doc.data();           // ドキュメントデータ { is_occupied: true, ... }
            const seatElement = document.getElementById(seatId); 

            if (seatElement) {
                // データの is_occupied の値に応じてスタイルを更新
                if (seat && seat.is_occupied) {
                    seatElement.style.backgroundColor = 'red'; // 使用中
                    // 日本語のテキストも更新（必要に応じて）
                    seatElement.textContent = seatElement.textContent.split(' ')[0].replace('', '') + '';
                } else {
                    seatElement.style.backgroundColor = '#acf3b7'; // 空き
                    seatElement.textContent = seatElement.textContent.split(' ')[0].replace('', '') + '';
                }
            }
        });
    }, (error) => {
        console.error("Firestoreリアルタイム監視エラー: ", error);
    });
}

// ----------------------------------------------------
// 4. ページ読み込み完了後にリスナーを開始
// ----------------------------------------------------
document.addEventListener('DOMContentLoaded', startFloorListener);